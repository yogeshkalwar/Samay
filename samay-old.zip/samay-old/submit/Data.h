
struct Behaviour{
        
	int iBorderStyle;
        bool bVisible;
        int iMaxTextW;
        int iMaxXCo ;
        int iMaxYCo ;
        int iAlignment;
	char* cTypeID;
        int iColorStyle;
};

struct Position{
        int iHeight;
        int iWidth;
        int iInitX;
        int iInitY;
        int iTabIndex;
};

