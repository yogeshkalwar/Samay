#include "samayGUI.h"

	Control::Control(){

	}

	
	
