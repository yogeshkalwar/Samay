#include "samayGUI.h"
class Controller
{
	private:
		GUIComponent* gVar; 
		GUIComponent* oAIndex[50];
		//int currWin;
	public:
		void registerComp(GUIComponent*);
		//void getFocus();
		
};

